@extends('layouts.app')
@section('y_css')
<style>
.content-wrapper .content .row .col-lg-2 , .col-lg-3, .col-lg-4{
  padding-left:10px;
  padding-right: 10px;
}
.activestate,.inactivestate,.emergencies,.invoices,.downloads,.response,.cpa{
  display:inline-block;
  //float:left;
  padding-right:10px;
}
.activestate span{
  margin-left: 10px;
}
.inactivestate span,.emergencies span,.invoices span,.downloads span,.response span{
  padding:0;
  margin:0;
  margin-left: 20px;
}
.activestate label,.inactivestate label,.emergencies label,.downloads label,.response label,.cpa label{
  padding: 0px 3px;
}
.invoices label{
  padding:0px 1px;
}
</style>
@endsection
@section('content')
<!-- Content Header (Page header) -->
<section class="content-header">
  <h1>
    Dashboard
    <small>For Month #Month Name#</small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="{{ url('/dashboard') }}"><i class="fa fa-dashboard"></i> Home</a></li>
    <li class="active">Dashboard</li>
  </ol>
</section>

<!-- Main content -->
<section class="content">
  <!-- Info boxes -->
  <div class="row">

    <div class="col-lg-2 col-md-4 col-sm-6 col-xs-12">
      <!-- small box -->
      <div class="small-box bg-green">
        <div class="inner"  > 
            <h4 class="text-uppercase">Operators</h4>
            <div class="activestate">
              <span>30</span><br/>
              <label class="bg-yellow">Active </label>
            </div>
            <div class="inactivestate">
              <span>10</span><br/>
              <label class="bg-red">InActive </label>
            </div>
          
        </div>
        <div class="icon" >
          <i class="fa fa-user"></i>
        </div>
        
      </div>
    </div>
    <div class="col-lg-2 col-md-4 col-sm-6 col-xs-12">
      <!-- small box -->
      <div class="small-box bg-yellow">
        <div class="inner">
            <h4 class="text-uppercase">Drivers</h4>
            <div class="activestate">
              <span>30</span><br/>
              <label class="bg-green">Active </label>
            </div>
            <div class="inactivestate">
              <span>10</span><br/>
              <label class="bg-red">InActive </label>
            </div>
        </div>
        <div class="icon" >
          <i class="fa fa-user"></i>
        </div>
        
      </div>
    </div>
    <div class="col-lg-2 col-md-4 col-sm-6 col-xs-12">
      <!-- small box -->
      <div class="small-box bg-red">
        <div class="inner">
            <h4 class="text-uppercase">Ambulances</h4>
            <div class="activestate">
              <span>30</span><br/>
              <label class="bg-green">Active </label>
            </div>
            <div class="inactivestate">
              <span>10</span><br/>
              <label class="bg-yellow">InActive </label>
            </div>
        </div>
        <div class="icon">
          <i class="fa fa-ambulance"></i>
        </div>

      </div>
    </div>
    <div class="col-lg-2 col-md-4 col-sm-6 col-xs-12">
      <!-- small box -->
      <div class="small-box bg-aqua">
        <div class="inner">
            <h4 class="text-uppercase">Hospitals</h4>
            <div class="activestate">
              <span>30</span><br/>
              <label class="bg-green">Active </label>
            </div>
            <div class="inactivestate">
              <span>15</span><br/>
              <label class="bg-red">InActive </label>
            </div>
        </div>
        <div class="icon">
          <i class="fa fa-hospital-o"></i>
        </div>
        
      </div>
    </div>
     <div class="col-lg-2 col-md-4 col-sm-6 col-xs-12">
      <!-- small box -->
      <div class="small-box bg-blue">
        <div class="inner">
            <h4 class="text-uppercase">Doctors</h4>
            <div class="activestate">
              <span>30</span><br/>
              <label class="bg-green">Active </label>
            </div>
            <div class="inactivestate">
              <span>10</span><br/>
              <label class="bg-red">InActive </label>
            </div>
        </div>
        <div class="icon" >
          <i class="fa fa-user-md"></i>
        </div>
        
      </div>
    </div>
    <div class="col-lg-2 col-md-4 col-sm-6 col-xs-12">
      <!-- small box -->
      <div class="small-box bg-purple">
        <div class="inner">
            <h4 class="text-uppercase">KeyPartners</h4>
            <div class="activestate">
              <span>30</span><br/>
              <label class="bg-green">Active </label>
            </div>
            <div class="inactivestate">
              <span>10</span><br/>
              <label class="bg-red">InActive </label>
            </div>
        </div>
        <div class="icon">
          <i class="fa fa-users"></i>
        </div>
        
      </div>
    </div>

</div>
  <!-- /.row -->
<div class="row">
 
    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
      <!-- small box -->
      <div class="small-box bg-blue">
        <div class="inner">
          <div class="inner-box text-center">
            <h4 class="text-uppercase">Emergencies [Ambulance]</h4>
            <div class="emergencies">
              <span>100</span><br/>
              <label class="bg-red">Generated </label>
            </div>
            <div class="emergencies">
              <span>50</span><br/>
              <label class="bg-green">Responded </label>
            </div>
            <div class="emergencies">
              <span>40</span><br/>
              <label class="bg-yellow">Rejected </label>
            </div>
          </div>
        </div>
        <div class="icon">
          <i class="fa fa-ambulance"></i>
        </div>

      </div>
    </div>
    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
      <!-- small box -->
      <div class="small-box bg-purple">
        <div class="inner">
          <div class="inner-box text-center">
            <h4 class="text-uppercase">Emergencies [Hospital]</h4>
            <div class="emergencies">
              <span>100</span><br/>
              <label class="bg-red">Generated </label>
            </div>
            <div class="emergencies">
              <span>50</span><br/>
              <label class="bg-green">Responded </label>
            </div>
            <div class="emergencies">
              <span>40</span><br/>
              <label class="bg-yellow">Rejected </label>
            </div>
          </div>
        </div>
        <div class="icon">
          <i class="fa fa-hospital-o"></i>
        </div>
        
      </div>
    </div>
</div>
  <!-- /.row -->
<div class="row">
  <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
      <!-- small box -->
      <div class="small-box bg-purple">
        <div class="inner">
            <h4 class="text-uppercase text-center">Invoice [Operator]</h4>
            <div class="invoices">
              <span>100</span><br/>
              <label class="bg-red">Bill Generated </label>
            </div>
            <div class="invoices">
              <span>30</span><br/>
              <label class="bg-red">Invoice Generated </label>
            </div>
            <div class="invoices">
              <span>50</span><br/>
              <label class="bg-green">Bill Paid</label>
            </div>
            <div class="invoices">
              <span>10</span><br/>
              <label class="bg-green">Invoice Paid</label>
            </div>
            <div class="invoices">
              <span>50</span><br/>
              <label class="bg-yellow">Bill UnPaid</label>
            </div>
            <div class="invoices">
              <span>20</span><br/>
              <label class="bg-yellow">Invoice UnPaid</label>
            </div>
          
        </div>
        <div class="icon">
          <i class="fa fa-users"></i>
        </div>

      </div>
    </div>
    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
      <!-- small box -->
      <div class="small-box bg-aqua">
        <div class="inner">
          <h4 class="text-uppercase text-center">Invoice [Hospital]</h4>
            <div class="invoices">
              <span>100</span><br/>
              <label class="bg-red">Bill Generated </label>
            </div>
            <div class="invoices">
              <span>30</span><br/>
              <label class="bg-red">Invoice Generated </label>
            </div>
            <div class="invoices">
              <span>50</span><br/>
              <label class="bg-green">Bill Paid</label>
            </div>
            <div class="invoices">
              <span>10</span><br/>
              <label class="bg-green">Invoice Paid</label>
            </div>
            <div class="invoices">
              <span>50</span><br/>
              <label class="bg-yellow">Bill UnPaid</label>
            </div>
            <div class="invoices">
              <span>20</span><br/>
              <label class="bg-yellow">Invoice UnPaid</label>
            </div>
          
        </div>
        <div class="icon">
          <i class="fa fa-hospital-o"></i>
        </div>
        
      </div>
    </div>

</div>
  <!-- /.row -->

<div class="row">
    <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
      <!-- small box -->
      <div class="small-box bg-blue">
        <div class="inner">
          <h4 class="text-uppercase">Response Time</h4>
            <div class="response">
              <span>3min</span><br/>
              <label class="bg-green">Average </label>
            </div>
             <div class="response">
              <span>2m</span><br/>
              <label class="bg-red">Minimum </label>
            </div>
             <div class="response">
              <span>4m</span><br/>
              <label class="bg-yellow">Maximum </label>
            </div>
          </div>
        <div class="icon">
          <i class="glyphicon glyphicon-time"></i>
        </div>
        
      </div>
    </div>

    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
      <!-- small box -->
      <div class="small-box bg-green">
        <div class="inner">
          <h4 class="text-uppercase">Downloads</h4>
            <div class="downloads">
              <span>300</span><br/>
              <label class="bg-red">Operators </label>
            </div>
            <div class="downloads">
              <span>500</span><br/>
              <label class="bg-red">Drivers </label>
            </div>
            <div class="downloads">
              <span>100</span><br/>
              <label class="bg-red">Hospitals </label>
            </div>
            <div class="downloads">
              <span>400</span><br/>
              <label class="bg-red">Doctors </label>
            </div>
            <div class="downloads">
              <span>800</span><br/>
              <label class="bg-red">Users </label>
            </div>
          
        </div>
        <div class="icon">
          <i class="fa fa-download"></i>
        </div>

      </div>
    </div>
    <div class="col-lg-5 col-md-5 col-sm-4 col-xs-12">
      <!-- small box -->
      <div class="small-box bg-red">
        <div class="inner">
          <h4 class="text-uppercase">Cost Per Acquisition</h4>
            <div class="cpa">
              <span>10k</span><br/>
              <label class="bg-purple">CPAA </label>
            </div>
            <div class="cpa">
              <span> 100k</span><br/>
              <label class="bg-yellow">CPAH </label>
            </div>
            <div class="cpa">
              <span>10k</span><br/>
              <label class="bg-blue">CPAU </label>
            </div>
            <div class="cpa">
              <span>10k</span><br/>
              <label class="bg-aqua">CPAK</label>
            </div>
            <div class="cpa">
              <span>10k</span><br/>
              <label class="bg-green">CPAD </label>
            </div>
        </div>
        <div class="icon" style="top:10px">
          <div style="font-size:20px;color:green">CPA=Cost Per Acquisition</div>
          <i class="fa fa-"></i>
        </div>
        
      </div>
    </div>
 
</div>
  <!-- /.row -->

  <div class="row">
    <div class="col-md-12">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Monthly Recap Report</h3>

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
            </button>
            <div class="btn-group">
              <button type="button" class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown">
                <i class="fa fa-wrench"></i></button>
              <ul class="dropdown-menu" role="menu">
                <li><a href="#">Action</a></li>
                <li><a href="#">Another action</a></li>
                <li><a href="#">Something else here</a></li>
                <li class="divider"></li>
                <li><a href="#">Separated link</a></li>
              </ul>
            </div>
            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
          </div>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <div class="row">
            <div class="col-md-8">
              <p class="text-center">
                <strong>Sales: 1 Jan, 2014 - 30 Jul, 2014</strong>
              </p>

              <div class="chart">
                <!-- Sales Chart Canvas -->
                <canvas id="salesChart" style="height: 180px;"></canvas>
              </div>
              <!-- /.chart-responsive -->
            </div>
            <!-- /.col -->
            <div class="col-md-4">
              <p class="text-center">
                <strong>Goal Completion</strong>
              </p>

              <div class="progress-group">
                <span class="progress-text">Add Products to Cart</span>
                <span class="progress-number"><b>160</b>/200</span>

                <div class="progress sm">
                  <div class="progress-bar progress-bar-aqua" style="width: 80%"></div>
                </div>
              </div>
              <!-- /.progress-group -->
              <div class="progress-group">
                <span class="progress-text">Complete Purchase</span>
                <span class="progress-number"><b>310</b>/400</span>

                <div class="progress sm">
                  <div class="progress-bar progress-bar-red" style="width: 80%"></div>
                </div>
              </div>
              <!-- /.progress-group -->
              <div class="progress-group">
                <span class="progress-text">Visit Premium Page</span>
                <span class="progress-number"><b>480</b>/800</span>

                <div class="progress sm">
                  <div class="progress-bar progress-bar-green" style="width: 80%"></div>
                </div>
              </div>
              <!-- /.progress-group -->
              <div class="progress-group">
                <span class="progress-text">Send Inquiries</span>
                <span class="progress-number"><b>250</b>/500</span>

                <div class="progress sm">
                  <div class="progress-bar progress-bar-yellow" style="width: 80%"></div>
                </div>
              </div>
              <!-- /.progress-group -->
            </div>
            <!-- /.col -->
          </div>
          <!-- /.row -->
        </div>
        <!-- ./box-body -->
        <div class="box-footer">
          <div class="row">
            <div class="col-sm-3 col-xs-6">
              <div class="description-block border-right">
                <span class="description-percentage text-green"><i class="fa fa-caret-up"></i> 17%</span>
                <h5 class="description-header">$35,210.43</h5>
                <span class="description-text">TOTAL REVENUE</span>
              </div>
              <!-- /.description-block -->
            </div>
            <!-- /.col -->
            <div class="col-sm-3 col-xs-6">
              <div class="description-block border-right">
                <span class="description-percentage text-yellow"><i class="fa fa-caret-left"></i> 0%</span>
                <h5 class="description-header">$10,390.90</h5>
                <span class="description-text">TOTAL COST</span>
              </div>
              <!-- /.description-block -->
            </div>
            <!-- /.col -->
            <div class="col-sm-3 col-xs-6">
              <div class="description-block border-right">
                <span class="description-percentage text-green"><i class="fa fa-caret-up"></i> 20%</span>
                <h5 class="description-header">$24,813.53</h5>
                <span class="description-text">TOTAL PROFIT</span>
              </div>
              <!-- /.description-block -->
            </div>
            <!-- /.col -->
            <div class="col-sm-3 col-xs-6">
              <div class="description-block">
                <span class="description-percentage text-red"><i class="fa fa-caret-down"></i> 18%</span>
                <h5 class="description-header">1200</h5>
                <span class="description-text">GOAL COMPLETIONS</span>
              </div>
              <!-- /.description-block -->
            </div>
          </div>
          <!-- /.row -->
        </div>
        <!-- /.box-footer -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->

  <!-- Main row -->
  <div class="row">
    <!-- Left col -->
    <div class="col-md-12">
      <!-- MAP & BOX PANE -->
      <div class="box box-success">
        <div class="box-header with-border">
          <h3 class="box-title">Visitors Report</h3>

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
            </button>
            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
          </div>
        </div>
        <!-- /.box-header -->
        <div class="box-body no-padding">
          <div class="row">
            <div class="col-md-9 col-sm-8">
              <div class="pad">
                <!-- Map will be created here -->
                <div id="world-map-markers" style="height: 325px;"></div>
              </div>
            </div>
            <!-- /.col -->
            <div class="col-md-3 col-sm-4">
              <div class="pad box-pane-right bg-green" style="min-height: 280px">
                <div class="description-block margin-bottom">
                  <div class="sparkbar pad" data-color="#fff">90,70,90,70,75,80,70</div>
                  <h5 class="description-header">8390</h5>
                  <span class="description-text">Visits</span>
                </div>
                <!-- /.description-block -->
                <div class="description-block margin-bottom">
                  <div class="sparkbar pad" data-color="#fff">90,50,90,70,61,83,63</div>
                  <h5 class="description-header">30%</h5>
                  <span class="description-text">Referrals</span>
                </div>
                <!-- /.description-block -->
                <div class="description-block">
                  <div class="sparkbar pad" data-color="#fff">90,50,90,70,61,83,63</div>
                  <h5 class="description-header">70%</h5>
                  <span class="description-text">Organic</span>
                </div>
                <!-- /.description-block -->
              </div>
            </div>
            <!-- /.col -->
          </div>
          <!-- /.row -->
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
      <div class="row">
         <div class="col-md-6">
          <!-- USERS LIST -->
          <div class="box box-danger">
            <div class="box-header with-border">
              <h3 class="box-title">Members</h3>

              <div class="box-tools pull-right">
                <span class="label label-danger">8 New Members</span>
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i>
                </button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body no-padding">
              <ul class="users-list clearfix">
                <li>
                  <img src="dist/img/user1-128x128.jpg" alt="User Image">
                  <a class="users-list-name" href="#">Alexander Pierce</a>
                  <span class="users-list-date">Today</span>
                </li>
                <li>
                  <img src="dist/img/user8-128x128.jpg" alt="User Image">
                  <a class="users-list-name" href="#">Norman</a>
                  <span class="users-list-date">Yesterday</span>
                </li>
                <li>
                  <img src="dist/img/user7-128x128.jpg" alt="User Image">
                  <a class="users-list-name" href="#">Jane</a>
                  <span class="users-list-date">12 Jan</span>
                </li>
                <li>
                  <img src="dist/img/user6-128x128.jpg" alt="User Image">
                  <a class="users-list-name" href="#">John</a>
                  <span class="users-list-date">12 Jan</span>
                </li>
                <li>
                  <img src="dist/img/user2-160x160.jpg" alt="User Image">
                  <a class="users-list-name" href="#">Alexander</a>
                  <span class="users-list-date">13 Jan</span>
                </li>
                <li>
                  <img src="dist/img/user5-128x128.jpg" alt="User Image">
                  <a class="users-list-name" href="#">Sarah</a>
                  <span class="users-list-date">14 Jan</span>
                </li>
                <li>
                  <img src="dist/img/user4-128x128.jpg" alt="User Image">
                  <a class="users-list-name" href="#">Nora</a>
                  <span class="users-list-date">15 Jan</span>
                </li>
                <li>
                  <img src="dist/img/user3-128x128.jpg" alt="User Image">
                  <a class="users-list-name" href="#">Nadia</a>
                  <span class="users-list-date">15 Jan</span>
                </li>
              </ul>
              <!-- /.users-list -->
            </div>
            <!-- /.box-body -->
            <div class="box-footer text-center">
              <a href="javascript:void(0)" class="uppercase">View All Users</a>
            </div>
            <!-- /.box-footer -->
          </div>
          <!--/.box -->
        </div>
        <!-- /.col -->
        <div class="col-md-6">
            <div class="box box-default">
                <div class="box-header with-border">
                  <h3 class="box-title">Browser Usage</h3>

                  <div class="box-tools pull-right">
                    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                    </button>
                    <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                  </div>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                  <div class="row">
                    <div class="col-md-8">
                      <div class="chart-responsive">
                        <canvas id="pieChart" height="150"></canvas>
                      </div>
                      <!-- ./chart-responsive -->
                    </div>
                    <!-- /.col -->
                    <div class="col-md-4">
                      <ul class="chart-legend clearfix">
                        <li><i class="fa fa-circle-o text-red"></i> Chrome</li>
                        <li><i class="fa fa-circle-o text-green"></i> IE</li>
                        <li><i class="fa fa-circle-o text-yellow"></i> FireFox</li>
                        <li><i class="fa fa-circle-o text-aqua"></i> Safari</li>
                        <li><i class="fa fa-circle-o text-light-blue"></i> Opera</li>
                        <li><i class="fa fa-circle-o text-gray"></i> Navigator</li>
                      </ul>
                    </div>
                    <!-- /.col -->
                  </div>
                  <!-- /.row -->
                </div>
                <!-- /.box-body -->
                <div class="box-footer no-padding">
                  <ul class="nav nav-pills nav-stacked">
                    <li><a href="#">United States of America
                      <span class="pull-right text-red"><i class="fa fa-angle-down"></i> 12%</span></a></li>
                    <li><a href="#">India <span class="pull-right text-green"><i class="fa fa-angle-up"></i> 4%</span></a>
                    </li>
                    <li><a href="#">China
                      <span class="pull-right text-yellow"><i class="fa fa-angle-left"></i> 0%</span></a></li>
                  </ul>
                </div>
                <!-- /.footer -->
              </div>
              <!-- /.box -->
         </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.col -->

  </div>
  <!-- /.row -->
</section>
@endsection
@section('script')
<script>
$(document).on("change", "#months", function() {
    var SelectedText = $(this).find("option:selected").text();
     var SelectedValue = $(this).find("option:selected").val();
    alert('Selected Value :' + SelectedValue+ '\n Selected Text :' + SelectedText );
    
});
</script>
@endsection